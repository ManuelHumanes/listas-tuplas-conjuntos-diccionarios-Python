"""
https://docs.python.org/3/tutorial/datastructures.html#more-on-lists
"""

#lista anidada / matrix

ciudades=[
    ["madrid","sevilla"],
    ["roma","milan"],
    ["moscu","kiev"]
]

ciudades.append(["berlin"])
print(ciudades)
for pais in ciudades:
    for i in pais:
        print(i)

#tupla
datos=10,"madrid",True,14.95
print(datos)

#sets no ordenado y sin duplicados
equipos={"rm","barcelona","atleti","betis",15}
print(equipos)

#diccionario
liga={
    "Real Madrid":50,
    "Barcelona":25,
    "Atleti":30,
    "Betis":35,
    "Getafe":10
}
print(liga)
liga["Betis"]=36 #update value
print(liga)
for i in liga.items():
    print(i[0],"--",i[1])

#reto1 ordena la liga (dictionary) por puntos de mayor a menor
liga = sorted(liga.items(), key=lambda x: x[1], reverse=True)
print(liga)

#tuplas con inmutables
tupla1=(2,"madrid",True,95)
print(tupla1)

#sets NO pueden tener valores duplicados
set={10,"madrid",False,19.54,10}
#no soporta duplicados, pero NO te da error
set.add("otro")
set.pop()
print(set)

#almacenar 5 alumnos con 4 asignaturas : notas del 0 al 10
#media de nota por alumno
#media de nota de la clase
#alumnos son : juan, maría, pedro, laura, manuel
#asignaturas son _ programación, bases de datos, diseño de interfaces, despliegue de aplicaciones
#listas / tuplas / set / dictionary

