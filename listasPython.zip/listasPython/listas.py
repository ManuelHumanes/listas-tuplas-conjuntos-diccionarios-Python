"""
Metodos en las listas
"""

def listas():
    elementos=["madrid",100,True,9.95,'juan',"valencia"]
    print(elementos)
    print(elementos.count("juan"))
    print(elementos.index("juan"))
    #elementos.reverse()
    print(elementos)
    print(elementos.index("juan"))
    elementos.append("zaragoza")
    print(elementos)
    elementos.pop()
    print(elementos)
    elementos.pop(2)
    print(elementos)
    elementos.remove("madrid")
    print(elementos)

#listas()

"""
pilas LIFO
colas FIFO : menos eficiente : append/pop colocarlos al inicio es más lento
"""

from collections import deque #por defecto phyton no trae las colas cargadas
def colas():
    datos=["rojo","verde","azul"]
    print(datos)
    datos.append("amarillo")
    print(datos)
    datos.popleft() #elimina FIFO
    print(datos)
#colas()
import time
def manipular_for():
    inicio = time.time_ns()
    cubo=[]
    for i in range(0,1000):
        cubo.append(i**3)
    print(cubo)
    fin = time.time_ns()
    print(fin-inicio)
#manipular_for()


def manipular_map():
    inicio = time.time_ns()
    cubo=list(map(lambda i:i**3,range(0,1000))) #programacion funcional
    print(cubo)
    fin = time.time_ns()
    print(fin-inicio)
#manipular_map()

"""
Crea una funcion para calcular el iva 21% de los importes 500 1000 1500 2000... asi hasta 1000000
suma de todos los importes
Promedio de todos los importes
mediante pop eliminar el primer importe
"""
def importe():
    inicio = time.time_ns()
    iva=[]
    for i in range(0,1000000,500):
        iva.append(i*1.21)
    print(iva)
    fin = time.time_ns()
    print(fin-inicio)
importe()