"""
lista - tuplas - sets (conjuntos) - diccionarios
https://www.educative.io/edpresso/list-vs-tuple-vs-set-vs-dictionary-in-python
"""

"""
listas
"""
lista=["madrid",True,10,9.54,'sevilla']
print(lista)
lista[2]="dato modificado" #lista es mutable, puede cambiar el valor de sus datos
print(lista)

"""
tuplas
"""
tupla=("madrid",True,10,9.54,'sevilla')
print(tupla)
#tupla[2]="dato modificado" #la tupla es inmutable y NO puede cambiar el valor de sus datos
print(tupla)

"""
set - conjuntos
"""
conjunto={"madrid",True,10,9.54,'sevilla'}
print(conjunto)
#conjunto[2]="dato modificado" # cuidado es mutable pero el error viene porque no puede identificarlo
#set es un conjutno de datos desordenados
print(conjunto)
conjunto.add("dato añadido") #conjunto es mutable pero no tiene orden

"""
diccionario
"""
diccionario={"item1":"madrid","item2":True,"item3":10,"item4":9.54,"item5":'sevilla'}
print(diccionario)
print(diccionario.keys())
print(diccionario.values())
print(diccionario.items())
diccionario["item2"]="dato modificado" #es mutable para valores por keys

"""
Ejercicio1
Vamos a almacenar los artículos que has elegido:
camisa, pantalón, sombrero, chaqueta, bufanda, zapatos
Muestra cuántos artículos tienes
Cambia el sombrero por gorra
¿Qué has elegido?*
"""
print("--------------------------------------------------------------------")
articulos=["camisa","pantalon","sombrero","chaqueta","bufanda","zapatos"]
print(articulos)
print(len(articulos))
articulos[2]="gorra"
print(articulos)

"""
Ejercicio2
Vamos a almacenar los artículos que has elegido:
camisa, pantalón, sombrero, chaqueta, bufanda, zapatos
Muestra cuántos artículos tienes
¿Qué has elegido?
"""
articulos1=("camisa","pantalon","sombrero","chaqueta","bufanda","zapatos")
print(len(articulos1))

"""
Ejercicio3
Vamos a almacenar los artículos que has elegido:
camisa, pantalón, sombrero, chaqueta, bufanda, zapatos
Muestra cuántos artículos tienes
la camisa cuesta 15.75, pantalón 8.95, sombrero 10, chaqueta 74.95, gufanda 9.98, zapatos 32.95
Muestra  el precio medio de los productos
Muestra el total del importe de todos los productos
¿Qué has elegido?
"""
articulos2={"camisa":"","pantalon":"","sombrero":"","chaqueta":"","bufanda":"","zapatos":""}
print(len(articulos2))
articulos2["camisa"]=15.75
articulos2["pantalon"]=8.95
articulos2["sombrero"]=10
articulos2["chaqueta"]=74.95
articulos2["bufanda"]=9.98
articulos2["zapatos"]=32.95
print(articulos2)
total=sum(articulos2.values())
print(total/len(articulos2))
print(sum(articulos2.values()))